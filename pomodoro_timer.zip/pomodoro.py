
import time

def countdown(minutes):
    seconds = minutes * 60
    while seconds:
        mins, secs = divmod(seconds, 60)
        time_format = f"{mins:02d}:{secs:02d}"
        print(time_format, end='\r')
        time.sleep(1)
        seconds -= 1

def pomodoro_timer(sessions=4):
    for session in range(1, sessions + 1):
        print(f"\nSession {session}: Work for 25 minutes.")
        countdown(25)  # or use a small number like 0.1 for quick testing
        if session < sessions:
            print("Take a 5-minute short break.")
            countdown(5)
        else:
            print("Take a 15-minute long break. Well done!")
            countdown(15)

if __name__ == "__main__":
    print("Pomodoro Timer Started!")
    pomodoro_timer()
